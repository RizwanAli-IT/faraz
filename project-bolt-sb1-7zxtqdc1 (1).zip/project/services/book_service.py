class BookService:
    def __init__(self, books):
        self.books = books
    
    def search_books(self, search_term):
        if not search_term:
            return [book.to_dict() for book in self.books]
        
        search_term = search_term.lower()
        return [book.to_dict() for book in self.books 
                if search_term in book.title.lower()]