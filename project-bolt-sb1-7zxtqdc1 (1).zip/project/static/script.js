document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const booksGrid = document.getElementById('booksGrid');

    function renderBooks(books, searchTerm) {
        if (!searchTerm) {
            booksGrid.innerHTML = '<div class="no-results">Enter a book name to start searching...</div>';
            return;
        }

        if (books.length === 0) {
            booksGrid.innerHTML = '<div class="no-results">No books found matching your search...</div>';
            return;
        }

        booksGrid.innerHTML = books.map(book => `
            <div class="book-card">
                <h2>${book.title}</h2>
                <p class="author">by ${book.author}</p>
                <div class="book-details">
                    <span class="year">${book.year}</span>
                    <span class="genre">${book.genre}</span>
                </div>
            </div>
        `).join('');
    }

    async function searchBooks() {
        const searchTerm = searchInput.value;
        const response = await fetch('/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `search=${encodeURIComponent(searchTerm)}`
        });
        const books = await response.json();
        renderBooks(books, searchTerm);
    }

    // Don't load books initially, show the prompt instead
    renderBooks([], '');

    // Search on input
    let debounceTimer;
    searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(searchBooks, 300);
    });
});