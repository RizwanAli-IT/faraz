import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(express.static('static'));
app.use(express.urlencoded({ extended: true }));

// Book data
const books = [
  { title: "The Great Gatsby", author: "F. Scott Fitzgerald", year: 1925, genre: "Classic" },
  { title: "To Kill a Mockingbird", author: "Harper Lee", year: 1960, genre: "Fiction" },
  { title: "1984", author: "George Orwell", year: 1949, genre: "Science Fiction" },
  { title: "Pride and Prejudice", author: "Jane Austen", year: 1813, genre: "Romance" },
  { title: "The Hobbit", author: "J.R.R. Tolkien", year: 1937, genre: "Fantasy" }
];

// Search functionality
function searchBooks(searchTerm) {
  if (!searchTerm) return books;
  searchTerm = searchTerm.toLowerCase();
  return books.filter(book => book.title.toLowerCase().includes(searchTerm));
}

app.get('/', (req, res) => {
  res.sendFile(join(__dirname, 'static', 'index.html'));
});

app.post('/search', (req, res) => {
  const results = searchBooks(req.body.search || '');
  res.json(results);
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});