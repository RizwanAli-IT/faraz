import { useState, useEffect } from 'react';
import { Trie } from './utils/Trie';
import { sampleBooks } from './data/sampleBooks';
import { Book } from './types/Book';
import './App.css';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<Book[]>([]);
  const [trie] = useState(() => {
    const t = new Trie();
    sampleBooks.forEach(book => t.insert(book));
    return t;
  });

  useEffect(() => {
    if (searchTerm.trim()) {
      const searchResults = trie.search(searchTerm);
      setResults(searchResults);
    } else {
      setResults(sampleBooks);
    }
  }, [searchTerm, trie]);

  return (
    <div className="container">
      <header>
        <h1>📚 Book Search Engine</h1>
        <div className="search-box">
          <input
            type="text"
            placeholder="Search for books..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </header>

      <main>
        <div className="books-grid">
          {results.map((book) => (
            <div key={book.id} className="book-card">
              <h2>{book.title}</h2>
              <p className="author">by {book.author}</p>
              <div className="book-details">
                <span className="year">{book.year}</span>
                <span className="genre">{book.genre}</span>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}