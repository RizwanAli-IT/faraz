// Trie implementation for efficient book searching
class TrieNode {
  children: Map<string, TrieNode>;
  isEndOfWord: boolean;
  books: Book[];

  constructor() {
    this.children = new Map();
    this.isEndOfWord = false;
    this.books = [];
  }
}

export class Trie {
  root: TrieNode;

  constructor() {
    this.root = new TrieNode();
  }

  insert(book: Book) {
    const words = book.title.toLowerCase().split(' ');
    words.forEach(word => {
      let node = this.root;
      
      for (const char of word) {
        if (!node.children.has(char)) {
          node.children.set(char, new TrieNode());
        }
        node = node.children.get(char)!;
      }
      
      node.isEndOfWord = true;
      node.books.push(book);
    });
  }

  search(prefix: string): Book[] {
    prefix = prefix.toLowerCase();
    let node = this.root;
    
    // Traverse to the last node of the prefix
    for (const char of prefix) {
      if (!node.children.has(char)) {
        return [];
      }
      node = node.children.get(char)!;
    }
    
    // Collect all books under this node
    return this.collectBooks(node);
  }

  private collectBooks(node: TrieNode): Book[] {
    const books: Book[] = [...node.books];
    
    for (const child of node.children.values()) {
      books.push(...this.collectBooks(child));
    }
    
    return [...new Set(books)]; // Remove duplicates
  }
}