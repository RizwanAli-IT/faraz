from flask import Flask, render_template, request
from data.books import books
from services.book_service import BookService

app = Flask(__name__)
book_service = BookService(books)

@app.route('/', methods=['GET', 'POST'])
def index():
    search_term = request.form.get('search', '')
    results = book_service.search_books(search_term)
    return render_template('index.html', books=results)

if __name__ == '__main__':
    app.run(debug=True)