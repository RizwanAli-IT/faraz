from models.book import Book

books = [
    Book("The Great Gatsby", "F. Scott Fitzgerald", 1925, "Classic"),
    Book("To Kill a Mockingbird", "Harper Lee", 1960, "Fiction"),
    Book("1984", "George Orwell", 1949, "Science Fiction"),
    Book("Pride and Prejudice", "Jane Austen", 1813, "Romance"),
    Book("The Hobbit", "J.R.R. Tolkien", 1937, "Fantasy")
]